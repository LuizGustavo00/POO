package br.Model;

import br.DAO.Database;
import java.sql.SQLException;
import java.util.ArrayList;


public class Gerencia extends Database{

    public void AdicionarCliente(){
        connectToDB();
        String sql = "INSERT Cliente_nome,Idconta FROM Conta";
    }

    public void mostrarClientes(){
        connectToDB();
        String sql = "SELECT Cliente_nome,Idconta FROM Conta";
        try {
            st = con.createStatement();
            rs = st.executeQuery(sql);
            System.out.println("Lista de Clientes: ");
            while(rs.next()){
                System.out.println(rs.getString("Cliente_nome") + " - Conta: " +rs.getInt("Idconta"));

            }

        }catch (SQLException e){
            System.out.println("Erro de operação: " + e.getMessage());
        }
    }
}
