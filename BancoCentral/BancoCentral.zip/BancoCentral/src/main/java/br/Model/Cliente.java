package br.Model;

import br.DAO.Database;

import java.sql.SQLException;
import java.util.ArrayList;

public class Cliente extends Database {

    String nome;

    public Cliente(String nome) {
        this.nome = nome;
    }

    public ArrayList<Cliente> inserir() {
        ArrayList<Cliente> clientes = new ArrayList<>();

        connectToDB();

        String sql = "SELECT * FROM Cliente";
        try {
            st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()) {
                User user1 = new User(rs.getString("nome"), rs.getString("senha"));

                System.out.println(user1.getNome());
                System.out.println(user1.getSenha());
            }
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
        return clientes;
    }



    public boolean authUsuario(String nome, String senha){
        boolean aux = true;
        connectToDB();
        String sql = "SELECT * FROM Cliente WHERE nome=? AND senha=?";

        try{
            pst = con.prepareStatement(sql);
            pst.setString(1, nome);
            pst.setString(2, senha);
            rs = pst.executeQuery();

            while(rs.next()){
                aux = false;
            }

        }catch (SQLException e){}


        return aux;
    }

    public void funcoes(String nome){
        System.out.println("Logou");
    }
}
